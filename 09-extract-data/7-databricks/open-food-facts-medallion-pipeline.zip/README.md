# 🥗 Open Food Facts Cloud Data Pipeline

An end-to-end, automated cloud **ELT pipeline** built to ingest raw product nutritional data from the Open Food Facts REST API, land unstructured payloads into Azure Blob Storage, and process them through a 3-tier **Medallion Architecture** using PySpark and Databricks Serverless.

---

## 🏗️ Architecture & Data Flow

```text
[ Open Food Facts REST API ]
             │
             ▼ (HTTP Ingestion with Rate-Limit Handling)
[ Azure Blob Storage (ADLS Gen2) ]
             │
             ▼ (Raw Ingestion + Metadata Audit)
[ Bronze Layer: foodfacts_catalog.bronze.food_facts ]
             │
             ▼ (Data Cleaning, Validation & Deduplication)
[ Silver Layer: foodfacts_catalog.silver.food_facts ]
             │
             ▼ (Business Aggregations & Metrics)
[ Gold Layer: foodfacts_catalog.gold.nutritional_summary ]

```
## 🛠️ Tech Stack & Technologies
- Cloud Storage: Azure Blob Storage / ADLS Gen2

- Data Processing & Compute: Databricks (Serverless PySpark)

- Data Governance & Cataloging: Unity Catalog (foodfacts_catalog)

- Orchestration & Workflow: Databricks Workflows (Sequential Multi-Task DAG)

- Version Control: Azure DevOps (Git)

- Data Format: Delta Lake (.delta) & JSON

## 🚀 Medallion Pipeline Design
**1. Ingestion & Landing (ELT)**
- Extracted data programmatically via the Open Food Facts API using custom retry logic and pagination handling.

- Stored raw, immutable JSON responses directly in Azure Blob Storage (raw-data container) prior to transformation.

**2. Bronze Layer (01_bronze_layer)**
- Reads raw JSON files from Azure Blob Storage into Delta Lake format.

- Preserves original payload schema while appending execution audit metadata (e.g., _ingested_at timestamp).

**3. Silver Layer (02_silver_layer)**
- Cleans and sanitizes product metadata.

- Filters out records missing essential attributes (e.g., product names, invalid Nutri-Scores).

- Deduplicates entries based on unique product barcodes and enforces explicit schema typing.

**4. Gold Layer (03_gold_layer)**
- Computes key business metrics aggregated by Nutri-Score grades (A through E).

- Generates summary metrics including average energy (kcal), sugar, and fat content per 100g serving.

## ⚙️ Orchestration & Automation
The pipeline is orchestrated using a Databricks Workflow Job (FoodFacts_Medallion_Pipeline), running tasks sequentially with strict dependency management:
```text
00_fetch_data ➔ 01_Bronze_Ingestion ➔ 02_Silver_Cleaning ➔ 03_Gold_Aggregation
```

## 📁 Repository Structure
```text
.
├── Bronze_Layer/
│   └── 01_bronze_layer.ipynb     # Raw Ingestion
├── Silver_Layer/
│   └── 02_silver_layer.ipynb     # PySpark Data Cleaning & Filtering
├── Gold_Layer/
│   └── 03_gold_layer.ipynb       # Analytical Aggregations & Business Metrics
├── fetch_API.ipynb               # API requests
└── README.md                     # Project Documentation

```
## 💡 Key Learnings & Takeaways
- Configured Unity Catalog three-level namespace (catalog.schema.table) for data governance.

- Addressed Databricks Serverless security policies using inline configuration bindings.

- Implemented production-grade error handling for external REST API ingestion.